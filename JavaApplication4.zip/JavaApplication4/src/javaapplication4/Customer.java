/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

/**
 *
 * @author mumin
 */
public class Customer {
     private String fullName;
    private String address;
    private String contactNumber;
    private String additionalContactNumber;

    public Customer(String fullName, String address, String contactNumber, String additionalContactNumber) {
        this.fullName = fullName;
        this.address = address;
        this.contactNumber = contactNumber;
        this.additionalContactNumber = additionalContactNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAdditionalContactNumber() {
        return additionalContactNumber;
    }

    public void setAdditionalContactNumber(String additionalContactNumber) {
        this.additionalContactNumber = additionalContactNumber;
    }
}
